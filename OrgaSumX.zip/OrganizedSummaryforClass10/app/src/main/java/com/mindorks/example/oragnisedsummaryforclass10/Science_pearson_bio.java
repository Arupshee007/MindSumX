package com.mindorks.example.oragnisedsummaryforclass10;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;



public class Science_pearson_bio extends AppCompatActivity {
    Button dark;
    Button light;
    RelativeLayout relativeLayout;
    Button pearson_plantlife;
    Button pearson_ecology;
    Button pearson_evolution;
    Button pearson_genetics;
    Button pearson_control;
    Button pearson_celldiv;
    Button pearson_cell;
    Button pearson_humanrepro;
    Button pearson_respire;
    Button pearson_excrete;
    Button pearson_plantrepro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_science_pearson_bio);

        relativeLayout = findViewById(R.id.rlVar1);
        // Define ActionBar object
        ActionBar actionBar;
        actionBar = getSupportActionBar();

        // Define ColorDrawable object and parse color
        // using parseColor method
        // with color hash code as its parameter
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#00BCD4"));

        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);

        dark = (Button) findViewById(R.id.dark_mode);
        dark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                relativeLayout.setBackgroundResource(R.color.black);

            }
        });

        light = (Button) findViewById(R.id.light_mode);
        light.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                relativeLayout.setBackgroundResource(R.color.white);

            }
        });

        pearson_cell = (Button) findViewById(R.id.pearson_bio_cell);
        pearson_cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Science_pearson_bio.this, Science_pearson_bio_cells.class);
                startActivity(intent);
            }
        });

        pearson_celldiv = (Button) findViewById(R.id.pearson_bio_celldiv);
        pearson_celldiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Science_pearson_bio.this, Science_pearson_bio_celldiv.class);
                startActivity(intent);
            }
        });

        pearson_plantlife = (Button) findViewById(R.id.pearson_bio_plantlife);
        pearson_plantlife.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Science_pearson_bio.this, Science_pearson_bio_plantlife.class);
                startActivity(intent);
            }
        });
    }
}