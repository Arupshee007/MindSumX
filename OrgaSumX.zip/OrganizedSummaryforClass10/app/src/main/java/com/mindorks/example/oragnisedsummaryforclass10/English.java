package com.mindorks.example.oragnisedsummaryforclass10;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;



public class English extends AppCompatActivity {


    Button eng_first_flight;
    Button eng_words;
    Button eng_footprints;
    RelativeLayout relativeLayout;
    Button eng_dark;
    Button eng_light;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english);

        eng_first_flight = (Button) findViewById(R.id.first_flight_eng);
        eng_first_flight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(English.this, English_firstfight.class);
                startActivity(intent);
            }
        });

        eng_words = (Button) findViewById(R.id.words_expressions);
        eng_words.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(English.this, English_wordsexpressions.class);
                startActivity(intent);
            }
        });

        eng_footprints = (Button) findViewById(R.id.footprints_without_feet);
        eng_footprints.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(English.this, English_footprints.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.rlVar1);
        // Define ActionBar object
        ActionBar actionBar;
        actionBar = getSupportActionBar();

        // Define ColorDrawable object and parse color
        // using parseColor method
        // with color hash code as its parameter
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#00BCD4"));

        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);

        eng_dark = (Button) findViewById(R.id.eng_dark_mode);
        eng_dark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                relativeLayout.setBackgroundResource(R.color.black);
            }
        });

        eng_light = (Button) findViewById(R.id.eng_light_mode);
        eng_light.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                relativeLayout.setBackgroundResource(R.color.white);
            }
        });

    }
}