package com.mindorks.example.oragnisedsummaryforclass10;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;



public class Science_ncert extends AppCompatActivity {
    Button dark;
    Button light;
    RelativeLayout relativeLayout;

    Button ncert_bio;
    Button ncert_phys;
    Button ncert_chem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_science_ncert);

        ncert_bio = (Button) findViewById(R.id.ncert_bio);
        ncert_bio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Science_ncert.this, Science_ncert_bio.class);
                startActivity(intent);
            }
        });

        ncert_chem = (Button) findViewById(R.id.ncert_chem);
        ncert_chem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Science_ncert.this, Science_ncert_chem.class);
                startActivity(intent);
            }
        });

        ncert_phys = (Button) findViewById(R.id.ncert_phys);
        ncert_phys.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Science_ncert.this, Science_ncert_phys.class);
                startActivity(intent);
            }
        });
        relativeLayout = findViewById(R.id.rlVar1);
        // Define ActionBar object
        ActionBar actionBar;
        actionBar = getSupportActionBar();

        // Define ColorDrawable object and parse color
        // using parseColor method
        // with color hash code as its parameter
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#00BCD4"));

        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);

        dark = (Button) findViewById(R.id.dark_mode);
        dark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                relativeLayout.setBackgroundResource(R.color.black);

                ncert_bio.setBackgroundColor(getResources().getColor(R.color.dark_red));
                ncert_chem.setBackgroundColor(getResources().getColor(R.color.dark_green));
                ncert_phys.setBackgroundColor(getResources().getColor(R.color.dark_violet));
            }
        });

        light = (Button) findViewById(R.id.light_mode);
        light.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                relativeLayout.setBackgroundResource(R.color.white);
                ncert_bio.setBackgroundColor(getResources().getColor(R.color.soft_red));
                ncert_chem.setBackgroundColor(getResources().getColor(R.color.soft_green));
                ncert_phys.setBackgroundColor(getResources().getColor(R.color.soft_violet));
            }
        });


    }
}