package com.mindorks.example.oragnisedsummaryforclass10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class English_firstfight extends AppCompatActivity {


    Button ff_prose;
    Button ff_poems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english_firstfight);

        ff_poems = (Button) findViewById(R.id.ff_poems);
        ff_poems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(English_firstfight.this, English_firstflight_poems.class);
                startActivity(intent);
            }
        });
        ff_prose = (Button) findViewById(R.id.ff_prose);
        ff_prose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(English_firstfight.this, English_firstflight_prose.class);
                startActivity(intent);
            }
        });
    }
}