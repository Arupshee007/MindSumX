package com.mindorks.example.oragnisedsummaryforclass10;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;



public class Science_ncert_chem extends AppCompatActivity {
    Button dark;
    Button light;
    RelativeLayout relativeLayout;
    Button ncert_acids;
    Button ncert_reactions;
    Button ncert_carbon;
    Button ncert_metals;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_science_ncert_chem);

        ncert_acids = (Button) findViewById(R.id.ncert_chem_acids);
        ncert_acids.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Science_ncert_chem.this, Science_ncert_chem_acids.class);
                startActivity(intent);
            }
        });

        ncert_carbon = (Button) findViewById(R.id.ncert_chem_carbon);
        ncert_carbon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Science_ncert_chem.this, Science_ncert_chem_carbon.class);
                startActivity(intent);
            }
        });

        ncert_metals = (Button) findViewById(R.id.ncert_chem_metals);
        ncert_metals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Science_ncert_chem.this, Science_ncert_chem_metals.class);
                startActivity(intent);
            }
        });

        ncert_reactions = (Button) findViewById(R.id.ncert_chem_reactions);
        ncert_reactions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Science_ncert_chem.this, Science_ncert_chem_reactions.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.rlVar1);
        // Define ActionBar object
        ActionBar actionBar;
        actionBar = getSupportActionBar();

        // Define ColorDrawable object and parse color
        // using parseColor method
        // with color hash code as its parameter
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#00BCD4"));

        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);

        dark = (Button) findViewById(R.id.dark_mode);
        dark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                relativeLayout.setBackgroundResource(R.color.black);
            }
        });

        light = (Button) findViewById(R.id.light_mode);
        light.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                relativeLayout.setBackgroundResource(R.color.white);
            }
        });

    }
}