package com.mindorks.example.oragnisedsummaryforclass10;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;


public class ApexSubjects extends AppCompatActivity {

    Button bengali;
    Button science;
    Button social_science;
    Button english;
    Button mathematics;
    RelativeLayout relativeLayout;
    Button sub_dark;
    Button sub_light;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apex_subject);
        bengali = (Button) findViewById(R.id.bengali_subchoice);
        bengali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ApexSubjects.this, Bengali.class);
                startActivity(intent);
            }
        });

        science = (Button) findViewById(R.id.science_subchoice);
        science.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ApexSubjects.this, Science.class);
                startActivity(intent);
            }
        });

        social_science = (Button) findViewById(R.id.social_science_subchoice);
        social_science.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ApexSubjects.this, SocialScience.class);
                startActivity(intent);
            }
        });

        english = (Button) findViewById(R.id.english_subchoice);
        english.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ApexSubjects.this, English.class);
                startActivity(intent);
            }
        });

        mathematics = (Button) findViewById(R.id.mathematics_subchoice);
        mathematics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ApexSubjects.this, Mathematics.class);
                startActivity(intent);
            }
        });


        relativeLayout = findViewById(R.id.rlVar1);
        // Define ActionBar object
        ActionBar actionBar;
        actionBar = getSupportActionBar();

        // Define ColorDrawable object and parse color
        // using parseColor method
        // with color hash code as its parameter
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#00BCD4"));

        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);

        sub_dark = (Button) findViewById(R.id.sub_dark_mode);
        sub_dark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                relativeLayout.setBackgroundResource(R.color.black);
                bengali.setBackgroundColor(getResources().getColor(R.color.dark_green));
                social_science.setBackgroundColor(getResources().getColor(R.color.dark_red));
                english.setBackgroundColor(getResources().getColor(R.color.dark_violet));
                mathematics.setBackgroundColor(getResources().getColor(R.color.dark_blue));
                science.setBackgroundColor(getResources().getColor(R.color.dark_purple));




            }
        });

        sub_light = (Button) findViewById(R.id.subjects_light_mode);
        sub_light.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                relativeLayout.setBackgroundResource(R.color.white);
                bengali.setBackgroundColor(getResources().getColor(R.color.soft_green));
                social_science.setBackgroundColor(getResources().getColor(R.color.soft_red));
                english.setBackgroundColor(getResources().getColor(R.color.soft_violet));
                mathematics.setBackgroundColor(getResources().getColor(R.color.soft_blue));
                science.setBackgroundColor(getResources().getColor(R.color.soft_purple));

            }
        });


    }
}