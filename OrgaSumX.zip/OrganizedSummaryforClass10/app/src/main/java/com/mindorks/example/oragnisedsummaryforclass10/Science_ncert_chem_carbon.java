package com.mindorks.example.oragnisedsummaryforclass10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;



public class Science_ncert_chem_carbon extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_science_ncert_chem_carbon);
    }
}