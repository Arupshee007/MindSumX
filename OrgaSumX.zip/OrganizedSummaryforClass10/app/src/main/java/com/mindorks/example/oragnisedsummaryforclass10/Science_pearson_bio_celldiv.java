package com.mindorks.example.oragnisedsummaryforclass10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.github.barteksc.pdfviewer.PDFView;

public class Science_pearson_bio_celldiv extends AppCompatActivity {
    PDFView pdfView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_science_pearson_bio_celldiv);
        pdfView=findViewById(R.id.pdfv);
        pdfView.fromAsset("Cell Division and Cell Cycle (Pearson).pdf").load();

    }

}