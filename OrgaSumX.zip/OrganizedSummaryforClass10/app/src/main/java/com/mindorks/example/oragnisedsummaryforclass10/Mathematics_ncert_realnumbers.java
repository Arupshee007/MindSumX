package com.mindorks.example.oragnisedsummaryforclass10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;



public class Mathematics_ncert_realnumbers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mathematics_ncert_realnumbers);
    }
}