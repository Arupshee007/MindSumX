package com.mindorks.example.oragnisedsummaryforclass10;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class English_firstflight_poems extends AppCompatActivity {


  Button ff_fire;
  Button ff_dust;
  Button ff_amanda;
  Button ff_animals;
  Button ff_fog;
  Button custard_i;
  Button ff_tiger;
  Button ff_trees;
  Button ff_ball;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english_firstflight_poems);

        ff_dust = (Button) findViewById(R.id.ff_peoms_dust);
        ff_dust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(English_firstflight_poems.this, English_firstflight_poems_dust.class);
                startActivity(intent);
            }
        });

        ff_amanda = (Button) findViewById(R.id.ff_peoms_amanda);
        ff_amanda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(English_firstflight_poems.this, English_firstflight_peoms_amanda.class);
                startActivity(intent);
            }
        });

        ff_animals = (Button) findViewById(R.id.ff_peoms_animals);
        ff_animals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(English_firstflight_poems.this, English_firstflight_poems_animals.class);
                startActivity(intent);
            }
        });
        // Define ActionBar object
        ActionBar actionBar;
        actionBar = getSupportActionBar();

        // Define ColorDrawable object and parse color
        // using parseColor method
        // with color hash code as its parameter
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#00BCD4"));

        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);

        ff_fire = (Button) findViewById(R.id.ff_peoms_fire);
        ff_fire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(English_firstflight_poems.this, English_firstflight_poems_fire.class);
                startActivity(intent);
            }


        });

        ff_tiger = (Button) findViewById(R.id.ff_poems_tiger_head);
        ff_tiger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(English_firstflight_poems.this, English_firstflight_poems_tiger.class);
                startActivity(intent);
            }
        });

        ff_fog = (Button) findViewById(R.id.ff_poems_fog);
        ff_fog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(English_firstflight_poems.this, English_firstflight_poems_fog.class);
                startActivity(intent);
            }
        });

        ff_trees = (Button) findViewById(R.id.ff_peoms_trees);
        ff_trees.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(English_firstflight_poems.this, English_firstflight_poems_trees.class);
                startActivity(intent);
            }
        });

        custard_i = (Button) findViewById(R.id.ff_peoms_custard);
        custard_i.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(English_firstflight_poems.this, English_firstflight_poems_custard_i.class);
                startActivity(intent);
            }
        });

        ff_ball = (Button) findViewById(R.id.ff_peoms_ball);
        ff_ball.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(English_firstflight_poems.this, English_firstflight_poems_ball.class);
                startActivity(intent);
            }
        });





    }
}