package com.mindorks.example.oragnisedsummaryforclass10;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;



public class Science_ls extends AppCompatActivity {
    Button dark;
    Button light;
    RelativeLayout relativeLayout;
    Button chem_ls;
    Button phys_ls;
    Button bio_ls;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_science_ls);

        chem_ls = (Button) findViewById(R.id.ls_chem);
        chem_ls.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Science_ls.this, Science_ls_chem.class);
                startActivity(intent);
            }
        });

        phys_ls = (Button) findViewById(R.id.ls_phys);
        phys_ls.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Science_ls.this, Science_ls_phys.class);
                startActivity(intent);
            }
        });

        bio_ls = (Button) findViewById(R.id.ls_bio);
        bio_ls.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Science_ls.this, Science_ls_bio.class);
                startActivity(intent);
            }
        });

        relativeLayout = findViewById(R.id.rlVar1);
        // Define ActionBar object
        ActionBar actionBar;
        actionBar = getSupportActionBar();

        // Define ColorDrawable object and parse color
        // using parseColor method
        // with color hash code as its parameter
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#00BCD4"));

        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);

        dark = (Button) findViewById(R.id.dark_mode);
        dark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                relativeLayout.setBackgroundResource(R.color.white);
                chem_ls.setBackgroundColor(getResources().getColor(R.color.dark_red));
                phys_ls.setBackgroundColor(getResources().getColor(R.color.dark_green));
                bio_ls.setBackgroundColor(getResources().getColor(R.color.dark_violet));
            }
        });

        light = (Button) findViewById(R.id.light_mode);
        light.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                relativeLayout.setBackgroundResource(R.color.white);
                chem_ls.setBackgroundColor(getResources().getColor(R.color.dark_red));
                phys_ls.setBackgroundColor(getResources().getColor(R.color.dark_green));
                bio_ls.setBackgroundColor(getResources().getColor(R.color.dark_violet));
            }
        });



    }
}