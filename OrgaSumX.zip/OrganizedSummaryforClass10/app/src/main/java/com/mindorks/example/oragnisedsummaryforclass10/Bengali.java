package com.mindorks.example.oragnisedsummaryforclass10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;



public class Bengali extends AppCompatActivity {

    Button rajkahini;
    Button sahitya;
    Button beng_grammar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bengali);

        rajkahini = (Button) findViewById(R.id.beng_rajkahini);
        rajkahini.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Bengali.this, Bengali_rajkahini.class);
                startActivity(intent);
            }
        });

        sahitya = (Button) findViewById(R.id.sahitya_sanchayan_book);
        sahitya.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Bengali.this, Bengali_sahitya.class);
                startActivity(intent);
            }
        });

        beng_grammar = (Button) findViewById(R.id.ben_grammar);
        beng_grammar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Bengali.this, Bengali_grammar.class);
                startActivity(intent);
            }
        });





    }
}