package com.mindorks.example.oragnisedsummaryforclass10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;


public class English_firstflight_poems_fire extends AppCompatActivity {

    Button dark;
    Button light;
    RelativeLayout relativeLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english_firstflight_poems_fire);

        dark = (Button) findViewById(R.id.dark_mode);
        dark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                relativeLayout.setBackgroundResource(R.color.black);
            }
        });

        light = (Button) findViewById(R.id.light_mode);
        light.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                relativeLayout.setBackgroundResource(R.color.white);
            }
        });

    }
}